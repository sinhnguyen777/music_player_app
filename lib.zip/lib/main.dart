import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';

import 'firebase_options_secure.dart';
import 'providers/auth_provider.dart';
import 'providers/home_provider.dart';
import 'providers/player_provider.dart';
import 'providers/playlist_provider.dart';
import 'screens/home_screen.dart';
import 'screens/playlists_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/search_screen.dart';
import 'widgets/mini_player.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load environment variables
  await dotenv.load(fileName: ".env");

  // Initialize Firebase with secure options
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(const MyApp());
}

const Color primaryGreen = Color(0xFF1B5E20);

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.system;
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()..init()),
        ChangeNotifierProvider(create: (_) => PlayerProvider()..init()),
        ChangeNotifierProvider(create: (_) => HomeProvider()..init()),
        ChangeNotifierProxyProvider<AuthProvider, PlaylistProvider>(
          create: (context) => PlaylistProvider(null),
          update: (context, auth, previous) {
            // Always create a new PlaylistProvider when auth changes
            print(
              'PlaylistProvider update - Auth: ${auth.isAuthenticated}, User: ${auth.user?.name}',
            );
            return PlaylistProvider(auth);
          },
        ),
      ],
      child: MaterialApp(
        title: 'SoundCloud Music',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: primaryGreen,
          colorScheme: ColorScheme.fromSeed(seedColor: primaryGreen),
          useMaterial3: true,
          brightness: Brightness.light,
          appBarTheme: const AppBarTheme(backgroundColor: primaryGreen),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: primaryGreen,
          ),
        ),
        darkTheme: ThemeData.dark().copyWith(
          primaryColor: primaryGreen,
          appBarTheme: const AppBarTheme(backgroundColor: primaryGreen),
        ),
        themeMode: _themeMode,
        home: const MainNav(),
      ),
    );
  }
}

class MainNav extends StatefulWidget {
  const MainNav({super.key});
  @override
  State<MainNav> createState() => _MainNavState();
}

class _MainNavState extends State<MainNav> {
  int _index = 0;
  final _pages = const [
    HomeScreen(),
    PlaylistsScreen(),
    SearchScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _pages[_index],
          const Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Column(children: [MiniPlayer()]),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        selectedItemColor: primaryGreen,
        type: BottomNavigationBarType.fixed,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.queue_music),
            label: 'Playlists',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
